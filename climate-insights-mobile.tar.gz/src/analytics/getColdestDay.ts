import type { DailyRecord } from "@/types/weather";

export function getColdestDay(records: DailyRecord[]): DailyRecord | null {
  let coldest: DailyRecord | null = null;
  for (const record of records) {
    if (record.tmin === null) continue;
    if (coldest === null || record.tmin < (coldest.tmin ?? Infinity)) {
      coldest = record;
    }
  }
  return coldest;
}
