import type { DailyRecord } from "@/types/weather";
import type { GrowingSeason } from "@/types/analytics";
import { monthOf, recordsForYear } from "./statsHelpers";

const MS_PER_DAY = 1000 * 60 * 60 * 24;

function daysBetween(startDate: string, endDate: string): number {
  const start = new Date(startDate).getTime();
  const end = new Date(endDate).getTime();
  return Math.round((end - start) / MS_PER_DAY);
}

export function getGrowingSeason(records: DailyRecord[], year: number): GrowingSeason {
  const yearRecords = recordsForYear(records, year);

  const firstHalf = yearRecords.filter((r) => monthOf(r.date) <= 6);
  const secondHalf = yearRecords.filter((r) => monthOf(r.date) > 6);

  const lastSpringFrost = [...firstHalf].reverse().find((r) => r.tmin !== null && r.tmin < 0);
  const firstAutumnFrost = secondHalf.find((r) => r.tmin !== null && r.tmin < 0);

  const startDate = lastSpringFrost ? lastSpringFrost.date : null;
  const endDate = firstAutumnFrost ? firstAutumnFrost.date : null;

  return {
    year,
    startDate,
    endDate,
    lengthDays: startDate && endDate ? daysBetween(startDate, endDate) : null,
  };
}
