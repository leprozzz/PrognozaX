import type { DailyRecord } from "@/types/weather";
import type { YearSummary } from "@/types/analytics";
import { average, nonNullValues, recordsForYear, sum } from "./statsHelpers";

export function getYearSummary(records: DailyRecord[], year: number): YearSummary {
  const yearRecords = recordsForYear(records, year);

  const tavgValues = nonNullValues(yearRecords.map((r) => r.tavg));
  const tmaxValues = nonNullValues(yearRecords.map((r) => r.tmax));
  const tminValues = nonNullValues(yearRecords.map((r) => r.tmin));
  const prcpValues = nonNullValues(yearRecords.map((r) => r.prcp));

  return {
    year,
    avgTemp: average(tavgValues),
    maxTemp: tmaxValues.length > 0 ? Math.max(...tmaxValues) : null,
    minTemp: tminValues.length > 0 ? Math.min(...tminValues) : null,
    summerDays: tmaxValues.filter((t) => t > 30).length,
    hotDays: tmaxValues.filter((t) => t > 35).length,
    frostDays: tminValues.filter((t) => t < 0).length,
    tropicalNights: tminValues.filter((t) => t > 20).length,
    totalPrecipitation: sum(prcpValues),
    daysWithData: tavgValues.length,
  };
}
