import type { DailyRecord } from "@/types/weather";

export function getFrostDays(records: DailyRecord[], thresholdC = 0): number {
  return records.filter((r) => r.tmin !== null && r.tmin < thresholdC).length;
}
