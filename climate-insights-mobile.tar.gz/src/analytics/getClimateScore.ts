import type { DailyRecord } from "@/types/weather";
import type { ClimateScore } from "@/types/analytics";
import { getYearSummary } from "./getYearSummary";

/**
 * NAPOMENA: Ova funkcija je zadržana u analytics modulu kao gotov
 * utility, ali se trenutno NE prikazuje u UI-ju (uklonjeno iz
 * Statistike po dogovoru — nepouzdano dok CSV podaci nisu potpuni za
 * sve godine/gradove). Ostavljena je za eventualnu buduću upotrebu.
 */
export function getClimateScore(records: DailyRecord[], year: number): ClimateScore {
  const allYears = [...new Set(records.map((r) => Number(r.date.slice(0, 4))))];
  const summaries = allYears.map((y) => getYearSummary(records, y));
  const targetSummary = summaries.find((s) => s.year === year) ?? getYearSummary(records, year);

  const avgTemps = summaries.map((s) => s.avgTemp).filter((v): v is number => v !== null);
  const baselineAvgTemp =
    avgTemps.length > 0 ? avgTemps.reduce((a, b) => a + b, 0) / avgTemps.length : 0;

  const tempDeviation = (targetSummary.avgTemp ?? baselineAvgTemp) - baselineAvgTemp;

  const extremeDaysScore =
    targetSummary.hotDays * 2 + targetSummary.frostDays * 1 + targetSummary.summerDays * 0.5;

  const rawScore = Math.abs(tempDeviation) * 10 + extremeDaysScore;
  const score = Math.min(100, Math.round(rawScore));

  let label = "Prosječna godina";
  if (score > 70) label = "Izrazito anomalna godina";
  else if (score > 40) label = "Primjetno odstupanje od prosjeka";
  else if (score > 15) label = "Blago odstupanje od prosjeka";

  return { year, score, label };
}
