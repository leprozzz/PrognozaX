import type { DailyRecord } from "@/types/weather";
import type { MonthlyAverage } from "@/types/analytics";
import { average, monthOf, nonNullValues, sum, yearOf } from "./statsHelpers";

export function getMonthlyAverage(records: DailyRecord[], year?: number): MonthlyAverage[] {
  const filtered = year !== undefined ? records.filter((r) => yearOf(r.date) === year) : records;

  const results: MonthlyAverage[] = [];

  for (let month = 1; month <= 12; month++) {
    const monthRecords = filtered.filter((r) => monthOf(r.date) === month);

    const tavgValues = nonNullValues(monthRecords.map((r) => r.tavg));
    const tminValues = nonNullValues(monthRecords.map((r) => r.tmin));
    const tmaxValues = nonNullValues(monthRecords.map((r) => r.tmax));
    const prcpValues = nonNullValues(monthRecords.map((r) => r.prcp));

    results.push({
      month,
      avgTemp: average(tavgValues),
      avgMin: average(tminValues),
      avgMax: average(tmaxValues),
      totalPrecipitation: sum(prcpValues),
    });
  }

  return results;
}
