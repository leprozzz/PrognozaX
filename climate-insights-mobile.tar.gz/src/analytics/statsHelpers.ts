import type { DailyRecord } from "@/types/weather";

export function nonNullValues(values: (number | null)[]): number[] {
  return values.filter((v): v is number => v !== null);
}

export function average(values: number[]): number | null {
  if (values.length === 0) return null;
  return values.reduce((sum, v) => sum + v, 0) / values.length;
}

export function sum(values: number[]): number {
  return values.reduce((s, v) => s + v, 0);
}

export function yearOf(date: string): number {
  return Number(date.slice(0, 4));
}

export function monthOf(date: string): number {
  return Number(date.slice(5, 7));
}

export function dayOf(date: string): number {
  return Number(date.slice(8, 10));
}

export function recordsForYear(records: DailyRecord[], year: number): DailyRecord[] {
  return records.filter((r) => yearOf(r.date) === year);
}

export function percentileRankOf(value: number, dataset: number[]): number {
  if (dataset.length === 0) return 0;
  const countBelowOrEqual = dataset.filter((v) => v <= value).length;
  return (countBelowOrEqual / dataset.length) * 100;
}
