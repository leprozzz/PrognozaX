import type { DailyRecord } from "@/types/weather";
import type { DailyComparison } from "@/types/analytics";
import { average, nonNullValues } from "./statsHelpers";
import { getHistoricalRanking } from "./getHistoricalRanking";

export function getDailyComparison(
  date: string,
  currentValue: number,
  historicalRecordsForDay: DailyRecord[],
  metric: "tavg" | "tmax" | "tmin" = "tavg",
): DailyComparison {
  const historicalValues = nonNullValues(historicalRecordsForDay.map((r) => r[metric]));

  const historicalAverage = average(historicalValues) ?? currentValue;
  const ranking = getHistoricalRanking(currentValue, historicalValues, "desc");

  let allTimeMax: { value: number; year: number } | null = null;
  let allTimeMin: { value: number; year: number } | null = null;

  for (const record of historicalRecordsForDay) {
    const value = record[metric];
    if (value === null) continue;
    const year = Number(record.date.slice(0, 4));
    if (allTimeMax === null || value > allTimeMax.value) allTimeMax = { value, year };
    if (allTimeMin === null || value < allTimeMin.value) allTimeMin = { value, year };
  }

  const isRecordCandidate =
    (allTimeMax !== null && currentValue >= allTimeMax.value - 1) ||
    (allTimeMin !== null && currentValue <= allTimeMin.value + 1);

  return {
    date,
    currentValue,
    historicalAverage,
    deltaFromAverage: currentValue - historicalAverage,
    percentileRank: ranking.percentile,
    isRecordCandidate,
    allTimeMax,
    allTimeMin,
    sampleSize: historicalValues.length,
  };
}
