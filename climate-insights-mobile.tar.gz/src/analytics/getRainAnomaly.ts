import type { DailyRecord } from "@/types/weather";
import type { RainAnomaly } from "@/types/analytics";
import { monthOf, nonNullValues, sum, yearOf } from "./statsHelpers";

export function getRainAnomaly(records: DailyRecord[], period: string): RainAnomaly {
  const [yearStr, monthStr] = period.split("-");
  const year = Number(yearStr);
  const month = Number(monthStr);

  const actualRecords = records.filter(
    (r) => yearOf(r.date) === year && monthOf(r.date) === month,
  );
  const actual = sum(nonNullValues(actualRecords.map((r) => r.prcp)));

  const allYears = [...new Set(records.map((r) => yearOf(r.date)))].filter((y) => y !== year);

  const yearlyTotals = allYears.map((y) => {
    const monthRecords = records.filter((r) => yearOf(r.date) === y && monthOf(r.date) === month);
    return sum(nonNullValues(monthRecords.map((r) => r.prcp)));
  });

  const historicalAverage =
    yearlyTotals.length > 0 ? sum(yearlyTotals) / yearlyTotals.length : actual;

  const deltaPercent =
    historicalAverage === 0 ? 0 : ((actual - historicalAverage) / historicalAverage) * 100;

  return { period, actual, historicalAverage, deltaPercent };
}
