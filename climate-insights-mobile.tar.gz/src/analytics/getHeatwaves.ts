import type { DailyRecord } from "@/types/weather";
import type { Heatwave } from "@/types/analytics";

export function getHeatwaves(
  records: DailyRecord[],
  thresholdC = 30,
  minDurationDays = 3,
): Heatwave[] {
  const heatwaves: Heatwave[] = [];
  let currentStreak: DailyRecord[] = [];

  const flushStreak = () => {
    if (currentStreak.length >= minDurationDays) {
      const temps = currentStreak.map((r) => r.tmax!).filter((t) => t !== null);
      heatwaves.push({
        startDate: currentStreak[0].date,
        endDate: currentStreak[currentStreak.length - 1].date,
        durationDays: currentStreak.length,
        maxTemp: Math.max(...temps),
      });
    }
    currentStreak = [];
  };

  for (const record of records) {
    if (record.tmax !== null && record.tmax >= thresholdC) {
      currentStreak.push(record);
    } else {
      flushStreak();
    }
  }
  flushStreak();

  return heatwaves;
}
