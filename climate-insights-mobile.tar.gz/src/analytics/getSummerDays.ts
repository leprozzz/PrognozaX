import type { DailyRecord } from "@/types/weather";

export function getSummerDays(records: DailyRecord[], thresholdC = 30): number {
  return records.filter((r) => r.tmax !== null && r.tmax > thresholdC).length;
}
