import type { DailyRecord } from "@/types/weather";

export function getHottestDay(records: DailyRecord[]): DailyRecord | null {
  let hottest: DailyRecord | null = null;
  for (const record of records) {
    if (record.tmax === null) continue;
    if (hottest === null || record.tmax > (hottest.tmax ?? -Infinity)) {
      hottest = record;
    }
  }
  return hottest;
}
