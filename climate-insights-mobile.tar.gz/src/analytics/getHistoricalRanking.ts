import type { HistoricalRanking } from "@/types/analytics";
import { percentileRankOf } from "./statsHelpers";

export function getHistoricalRanking(
  value: number,
  dataset: number[],
  direction: "desc" | "asc" = "desc",
): HistoricalRanking {
  if (dataset.length === 0) {
    return { rank: 1, totalRecords: 0, percentile: 0 };
  }

  const sorted = [...dataset].sort((a, b) => (direction === "desc" ? b - a : a - b));

  const moreExtremeCount = sorted.filter((v) =>
    direction === "desc" ? v > value : v < value,
  ).length;

  return {
    rank: moreExtremeCount + 1,
    totalRecords: dataset.length,
    percentile: percentileRankOf(value, dataset),
  };
}
