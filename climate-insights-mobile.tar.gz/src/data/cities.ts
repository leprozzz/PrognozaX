import type { City, CitiesConfig } from "@/types/city";

let citiesCache: City[] | null = null;

export async function getCities(): Promise<City[]> {
  if (citiesCache) {
    return citiesCache;
  }

  const response = await fetch("/data/cities.json");
  if (!response.ok) {
    throw new Error(`Neuspješno učitavanje cities.json: ${response.status}`);
  }

  const config: CitiesConfig = await response.json();
  citiesCache = config;
  return config;
}

export async function getCityById(cityId: string): Promise<City | undefined> {
  const cities = await getCities();
  return cities.find((city) => city.id === cityId);
}
