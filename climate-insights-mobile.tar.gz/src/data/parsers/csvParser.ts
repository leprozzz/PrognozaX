import Papa from "papaparse";
import type { DailyRecord } from "@/types/weather";

interface RawCsvRow {
  date: string;
  tavg: string;
  tmin: string;
  tmax: string;
  prcp: string;
}

/**
 * Fizički razumne granice za dnevnu temperaturu na ovim geografskim
 * širinama (nizijski i brdski gradovi BiH). Apsolutni rekord za BiH je
 * 43.1°C (Mostar, 2007) i -42.5°C (Igman, planinska stanica) — ove
 * granice su namjerno šire od toga da ne bismo slučajno odsjekli
 * legitiman rijedak ekstrem, ali dovoljno uske da uhvate senzorske
 * greške poput 54°C ili -40°C u nizijskom gradu.
 */
const MIN_PLAUSIBLE_TEMP_C = -45;
const MAX_PLAUSIBLE_TEMP_C = 48;
const MAX_PLAUSIBLE_PRCP_MM = 500;

function parseNullableNumber(value: string | undefined): number | null {
  if (value === undefined || value.trim() === "" || value.trim().toLowerCase() === "nan") {
    return null;
  }
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function sanitizeTemp(value: number | null): number | null {
  if (value === null) return null;
  if (value < MIN_PLAUSIBLE_TEMP_C || value > MAX_PLAUSIBLE_TEMP_C) return null;
  return value;
}

function sanitizePrcp(value: number | null): number | null {
  if (value === null) return null;
  if (value < 0 || value > MAX_PLAUSIBLE_PRCP_MM) return null;
  return value;
}

/**
 * Parsira sirovi CSV tekst (format: date,tavg,tmin,tmax,prcp) u niz
 * tipiziranih DailyRecord objekata, sortiran po datumu rastuće.
 * Fizički nemoguće vrijednosti se odbacuju (postaju null) uz upozorenje
 * u konzoli, umjesto da iskrive statistiku.
 */
export function parseHistoricalCsv(csvText: string): DailyRecord[] {
  const result = Papa.parse<RawCsvRow>(csvText, {
    header: true,
    skipEmptyLines: true,
  });

  if (result.errors.length > 0) {
    console.warn("CSV parsing upozorenja:", result.errors);
  }

  let rejectedCount = 0;

  const records: DailyRecord[] = result.data
    .filter((row) => row.date)
    .map((row) => {
      const rawTavg = parseNullableNumber(row.tavg);
      const rawTmin = parseNullableNumber(row.tmin);
      const rawTmax = parseNullableNumber(row.tmax);
      const rawPrcp = parseNullableNumber(row.prcp);

      const tavg = sanitizeTemp(rawTavg);
      const tmin = sanitizeTemp(rawTmin);
      const tmax = sanitizeTemp(rawTmax);
      const prcp = sanitizePrcp(rawPrcp);

      if (tavg !== rawTavg || tmin !== rawTmin || tmax !== rawTmax || prcp !== rawPrcp) {
        rejectedCount++;
      }

      return { date: row.date.trim(), tavg, tmin, tmax, prcp };
    });

  if (rejectedCount > 0) {
    console.warn(
      `parseHistoricalCsv: ${rejectedCount} dan(a) je imalo fizički nemoguću vrijednost i tretiran je kao nedostajući podatak.`,
    );
  }

  records.sort((a, b) => a.date.localeCompare(b.date));

  return records;
}
