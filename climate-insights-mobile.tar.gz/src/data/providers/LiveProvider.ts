import type { LiveSnapshot } from "@/types/weather";
import type { LiveDataProvider } from "./WeatherDataProvider";
import { getCityById } from "../cities";

const OPEN_METEO_BASE_URL = "https://api.open-meteo.com/v1/forecast";

interface OpenMeteoResponse {
  current: { temperature_2m: number; precipitation: number };
  daily: {
    time: string[];
    temperature_2m_max: number[];
    temperature_2m_min: number[];
    precipitation_sum: number[];
  };
}

class OpenMeteoLiveProvider implements LiveDataProvider {
  async getCurrentConditions(cityId: string): Promise<LiveSnapshot> {
    const city = await getCityById(cityId);
    if (!city) throw new Error(`Nepoznat grad: ${cityId}`);

    const url = new URL(OPEN_METEO_BASE_URL);
    url.searchParams.set("latitude", String(city.latitude));
    url.searchParams.set("longitude", String(city.longitude));
    url.searchParams.set("current", "temperature_2m,precipitation");
    url.searchParams.set("daily", "temperature_2m_max,temperature_2m_min,precipitation_sum");
    url.searchParams.set("timezone", "auto");
    url.searchParams.set("forecast_days", "7");

    const response = await fetch(url.toString());
    if (!response.ok) {
      throw new Error(`Neuspješno preuzimanje live podataka za ${city.name}: ${response.status}`);
    }

    const data: OpenMeteoResponse = await response.json();

    return {
      cityId,
      current: data.current.temperature_2m,
      todayMax: data.daily.temperature_2m_max[0],
      todayMin: data.daily.temperature_2m_min[0],
      precipitation: data.daily.precipitation_sum[0],
      forecast: data.daily.time.slice(1).map((date, idx) => ({
        date,
        tmax: data.daily.temperature_2m_max[idx + 1],
        tmin: data.daily.temperature_2m_min[idx + 1],
        precipitation: data.daily.precipitation_sum[idx + 1],
      })),
      fetchedAt: new Date().toISOString(),
    };
  }
}

export const liveProvider: LiveDataProvider = new OpenMeteoLiveProvider();
