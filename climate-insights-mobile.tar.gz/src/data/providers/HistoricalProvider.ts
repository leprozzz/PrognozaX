import type { DailyRecord } from "@/types/weather";
import type { HistoricalDataProvider } from "./WeatherDataProvider";
import { parseHistoricalCsv } from "../parsers/csvParser";
import { getCityById } from "../cities";

class CsvHistoricalProvider implements HistoricalDataProvider {
  private cache = new Map<string, Promise<DailyRecord[]>>();

  async getHistoricalData(cityId: string): Promise<DailyRecord[]> {
    const cached = this.cache.get(cityId);
    if (cached) return cached;

    const promise = this.loadCsv(cityId);
    this.cache.set(cityId, promise);
    return promise;
  }

  private async loadCsv(cityId: string): Promise<DailyRecord[]> {
    const city = await getCityById(cityId);
    if (!city) throw new Error(`Nepoznat grad: ${cityId}`);

    const response = await fetch(city.csvPath);
    if (!response.ok) {
      throw new Error(`Neuspješno učitavanje CSV-a za ${city.name}: ${response.status}`);
    }

    const csvText = await response.text();
    return parseHistoricalCsv(csvText);
  }

  async getDailyRecord(cityId: string, date: string): Promise<DailyRecord | null> {
    const records = await this.getHistoricalData(cityId);
    return records.find((record) => record.date === date) ?? null;
  }

  async getRecordsForCalendarDay(
    cityId: string,
    month: number,
    day: number,
  ): Promise<DailyRecord[]> {
    const records = await this.getHistoricalData(cityId);
    const suffix = `-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
    return records.filter((record) => record.date.endsWith(suffix));
  }
}

export const historicalProvider: HistoricalDataProvider = new CsvHistoricalProvider();
