import type { DailyRecord, LiveSnapshot } from "@/types/weather";

export interface HistoricalDataProvider {
  getHistoricalData(cityId: string): Promise<DailyRecord[]>;
  getDailyRecord(cityId: string, date: string): Promise<DailyRecord | null>;
  getRecordsForCalendarDay(cityId: string, month: number, day: number): Promise<DailyRecord[]>;
}

export interface LiveDataProvider {
  getCurrentConditions(cityId: string): Promise<LiveSnapshot>;
}
