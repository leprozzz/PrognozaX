export type ComparisonTone = "extreme-hot" | "hot" | "normal" | "cold" | "extreme-cold";

export interface ComparisonCategory {
  label: string;
  tone: ComparisonTone;
}

/**
 * Kategorizuje odstupanje od istorijskog prosjeka po pragovima
 * dogovorenim za "Na današnji dan":
 *   > +8°C  → Ekstremno toplije nego obično
 *   > +4°C  → Toplije nego obično
 *   ±4°C    → Približno prosječno
 *   < -4°C  → Hladnije nego obično
 *   < -8°C  → Ekstremno hladnije nego obično
 */
export function categorizeDelta(delta: number): ComparisonCategory {
  if (delta > 8) return { label: "Ekstremno toplije nego obično", tone: "extreme-hot" };
  if (delta > 4) return { label: "Toplije nego obično", tone: "hot" };
  if (delta < -8) return { label: "Ekstremno hladnije nego obično", tone: "extreme-cold" };
  if (delta < -4) return { label: "Hladnije nego obično", tone: "cold" };
  return { label: "Približno prosječno", tone: "normal" };
}
