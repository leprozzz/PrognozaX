/**
 * Vraća trenutni sat (0-23) u datoj IANA vremenskoj zoni — koristi se
 * da odredimo da li je "dan" (07-23h) ili "noć" (23-07h) za odabir
 * ispravne istorijske osnove poređenja (prosjek maksimalnih vs
 * minimalnih temperatura) na "Na današnji dan" stranici.
 */
export function getHourInTimezone(timezone: string): number {
  const formatter = new Intl.DateTimeFormat("en-GB", {
    timeZone: timezone,
    hour: "numeric",
    hourCycle: "h23",
  });
  return Number(formatter.format(new Date()));
}

export function isDaytimeHour(hour: number): boolean {
  return hour >= 7 && hour < 23;
}
