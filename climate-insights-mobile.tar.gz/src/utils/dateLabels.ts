const MONTHS_GENITIVE = [
  "januara", "februara", "marta", "aprila", "maja", "juna",
  "jula", "avgusta", "septembra", "oktobra", "novembra", "decembra",
];

export function formatCalendarDayGenitive(month: number, day: number): string {
  return `${day}. ${MONTHS_GENITIVE[month - 1]}`;
}
