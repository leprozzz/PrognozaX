import { create } from "zustand";
import { persist } from "zustand/middleware";

export type Theme = "light" | "dark";

interface AppState {
  selectedCityId: string;
  setSelectedCityId: (cityId: string) => void;

  theme: Theme;
  toggleTheme: () => void;
  setTheme: (theme: Theme) => void;
}

export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      selectedCityId: "banja-luka",
      setSelectedCityId: (cityId) => set({ selectedCityId: cityId }),

      theme: "light",
      toggleTheme: () =>
        set((state) => ({ theme: state.theme === "light" ? "dark" : "light" })),
      setTheme: (theme) => set({ theme }),
    }),
    { name: "climate-insights-store" },
  ),
);
