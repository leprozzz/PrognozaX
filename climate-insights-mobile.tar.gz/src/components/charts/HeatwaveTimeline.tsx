import { format, parseISO } from "date-fns";
import { bs } from "date-fns/locale";
import type { Heatwave } from "@/types/analytics";

interface Props {
  heatwaves: Heatwave[];
  limit?: number;
}

export function HeatwaveTimeline({ heatwaves, limit = 8 }: Props) {
  const sorted = [...heatwaves].sort((a, b) => b.startDate.localeCompare(a.startDate));
  const visible = sorted.slice(0, limit);

  if (visible.length === 0) {
    return (
      <p className="text-sm text-zinc-500 dark:text-zinc-400">
        Nema zabilježenih toplotnih talasa u posmatranom periodu.
      </p>
    );
  }

  const maxDuration = Math.max(...visible.map((h) => h.durationDays));

  return (
    <div className="flex flex-col gap-3">
      {visible.map((wave) => {
        const widthPercent = Math.max(12, (wave.durationDays / maxDuration) * 100);
        const intensity =
          wave.maxTemp >= 38 ? "bg-heat-600" : wave.maxTemp >= 34 ? "bg-heat-500" : "bg-heat-400";

        return (
          <div key={`${wave.startDate}-${wave.endDate}`} className="flex items-center gap-3">
            <div className="w-24 shrink-0 whitespace-nowrap text-xs text-zinc-500 dark:text-zinc-400">
              {format(parseISO(wave.startDate), "d MMM yyyy", { locale: bs })}
            </div>
            <div className="flex-1">
              <div
                className={`h-2.5 rounded-full ${intensity}`}
                style={{ width: `${widthPercent}%` }}
              />
            </div>
            <div className="data-figure w-32 shrink-0 whitespace-nowrap text-right text-xs text-zinc-600 dark:text-zinc-300">
              {wave.durationDays} {wave.durationDays === 1 ? "dan" : "dana"} · {wave.maxTemp.toFixed(1)}°C
            </div>
          </div>
        );
      })}
    </div>
  );
}
