import { useChartColors } from "@/hooks/useChartColors";

interface TooltipPayloadEntry {
  dataKey?: string | number;
  name?: string | number;
  value?: number | string;
  color?: string;
}

interface ChartTooltipProps {
  active?: boolean;
  payload?: TooltipPayloadEntry[];
  label?: string | number;
  formatter?: (value: number, name: string) => string;
}

export function ChartTooltip({ active, payload, label, formatter }: ChartTooltipProps) {
  const colors = useChartColors();

  if (!active || !payload || payload.length === 0) return null;

  return (
    <div
      className="rounded-md border px-3 py-2 text-xs shadow-sm"
      style={{ background: colors.tooltipBg, borderColor: colors.tooltipBorder }}
    >
      <div className="mb-1 font-medium text-zinc-500 dark:text-zinc-400">{label}</div>
      {payload.map((entry) => (
        <div key={String(entry.dataKey)} className="flex items-center gap-1.5">
          <span className="h-2 w-2 rounded-full" style={{ background: entry.color }} />
          <span className="text-zinc-700 dark:text-zinc-200">
            {formatter && typeof entry.value === "number"
              ? formatter(entry.value, String(entry.name))
              : `${entry.value}`}
          </span>
        </div>
      ))}
    </div>
  );
}
