import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { useChartColors } from "@/hooks/useChartColors";
import { ChartTooltip } from "./ChartTooltip";
import type { YearSummary } from "@/types/analytics";

interface Props {
  summaries: YearSummary[];
}

export function YearlyTemperatureTrendChart({ summaries }: Props) {
  const colors = useChartColors();

  const data = summaries.map((s) => ({
    year: s.year,
    avgTemp: s.avgTemp !== null ? Number(s.avgTemp.toFixed(1)) : null,
  }));

  return (
    <ResponsiveContainer width="100%" height={260}>
      <LineChart data={data} margin={{ top: 8, right: 16, left: -4, bottom: 0 }}>
        <CartesianGrid stroke={colors.grid} vertical={false} />
        <XAxis
          dataKey="year"
          stroke={colors.axis}
          tick={{ fill: colors.text, fontSize: 12 }}
          tickLine={false}
          axisLine={{ stroke: colors.grid }}
        />
        <YAxis
          stroke={colors.axis}
          tick={{ fill: colors.text, fontSize: 12 }}
          tickLine={false}
          axisLine={false}
          tickFormatter={(value) => `${value}°C`}
          width={52}
        />
        <Tooltip
          content={
            <ChartTooltip formatter={(value) => `${(value ?? 0).toFixed(1)}°C prosječno`} />
          }
        />
        <Line
          type="monotone"
          dataKey="avgTemp"
          name="Prosječna temperatura"
          stroke={colors.brand}
          strokeWidth={2}
          dot={{ r: 3, fill: colors.brand }}
          activeDot={{ r: 5 }}
          connectNulls
        />
      </LineChart>
    </ResponsiveContainer>
  );
}
