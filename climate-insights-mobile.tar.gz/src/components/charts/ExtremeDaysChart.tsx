import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  Cell,
  ResponsiveContainer,
} from "recharts";
import { useChartColors } from "@/hooks/useChartColors";
import { ChartTooltip } from "./ChartTooltip";
import type { YearSummary } from "@/types/analytics";

interface Props {
  summaries: YearSummary[];
  selectedYear?: number;
}

export function ExtremeDaysChart({ summaries, selectedYear }: Props) {
  const colors = useChartColors();

  const data = summaries.map((s) => ({
    year: s.year,
    summerDays: s.summerDays,
    frostDays: s.frostDays,
  }));

  const opacityFor = (year: number) =>
    selectedYear === undefined || year === selectedYear ? 1 : 0.35;

  return (
    <ResponsiveContainer width="100%" height={260}>
      <BarChart data={data} margin={{ top: 8, right: 16, left: -4, bottom: 0 }}>
        <CartesianGrid stroke={colors.grid} vertical={false} />
        <XAxis
          dataKey="year"
          stroke={colors.axis}
          tick={{ fill: colors.text, fontSize: 12 }}
          tickLine={false}
          axisLine={{ stroke: colors.grid }}
        />
        <YAxis
          stroke={colors.axis}
          tick={{ fill: colors.text, fontSize: 12 }}
          tickLine={false}
          axisLine={false}
          width={32}
        />
        <Tooltip content={<ChartTooltip formatter={(value) => `${value} dana`} />} />
        <Legend
          wrapperStyle={{ fontSize: 12, color: colors.text }}
          formatter={(value) =>
            value === "summerDays" ? "Ljetni dani (>30°C)" : "Mrazni dani (<0°C)"
          }
        />
        <Bar dataKey="summerDays" radius={[3, 3, 0, 0]}>
          {data.map((entry) => (
            <Cell key={entry.year} fill={colors.heat} fillOpacity={opacityFor(entry.year)} />
          ))}
        </Bar>
        <Bar dataKey="frostDays" radius={[3, 3, 0, 0]}>
          {data.map((entry) => (
            <Cell key={entry.year} fill={colors.cold} fillOpacity={opacityFor(entry.year)} />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}
