import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Cell,
  ResponsiveContainer,
} from "recharts";
import { useChartColors } from "@/hooks/useChartColors";
import { ChartTooltip } from "./ChartTooltip";
import type { YearSummary } from "@/types/analytics";

interface Props {
  summaries: YearSummary[];
  selectedYear?: number;
}

export function PrecipitationChart({ summaries, selectedYear }: Props) {
  const colors = useChartColors();

  const data = summaries.map((s) => ({
    year: s.year,
    precipitation: Number(s.totalPrecipitation.toFixed(0)),
  }));

  const opacityFor = (year: number) =>
    selectedYear === undefined || year === selectedYear ? 1 : 0.35;

  return (
    <ResponsiveContainer width="100%" height={260}>
      <BarChart data={data} margin={{ top: 8, right: 16, left: -4, bottom: 0 }}>
        <CartesianGrid stroke={colors.grid} vertical={false} />
        <XAxis
          dataKey="year"
          stroke={colors.axis}
          tick={{ fill: colors.text, fontSize: 12 }}
          tickLine={false}
          axisLine={{ stroke: colors.grid }}
        />
        <YAxis
          stroke={colors.axis}
          tick={{ fill: colors.text, fontSize: 12 }}
          tickLine={false}
          axisLine={false}
          tickFormatter={(value) => `${value}mm`}
          width={56}
        />
        <Tooltip content={<ChartTooltip formatter={(value) => `${value} mm`} />} />
        <Bar dataKey="precipitation" name="Padavine" radius={[3, 3, 0, 0]}>
          {data.map((entry) => (
            <Cell key={entry.year} fill={colors.coldLight} fillOpacity={opacityFor(entry.year)} />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}
