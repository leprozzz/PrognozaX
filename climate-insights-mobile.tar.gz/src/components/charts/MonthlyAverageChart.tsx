import {
  ComposedChart,
  Area,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { useChartColors } from "@/hooks/useChartColors";
import { ChartTooltip } from "./ChartTooltip";
import type { MonthlyAverage } from "@/types/analytics";

const MONTH_LABELS = [
  "Jan", "Feb", "Mar", "Apr", "Maj", "Jun",
  "Jul", "Avg", "Sep", "Okt", "Nov", "Dec",
];

interface Props {
  monthlyAverages: MonthlyAverage[];
  /** Opciono: mjesečni prosjeci za JEDNU konkretnu godinu, prikazani kao
   * dodatna linija preko klimatskog normala — omogućava direktno
   * poređenje "ova godina vs prosjek" na istom grafu. */
  yearOverlay?: { year: number; data: MonthlyAverage[] };
}

export function MonthlyAverageChart({ monthlyAverages, yearOverlay }: Props) {
  const colors = useChartColors();

  const data = monthlyAverages.map((m, idx) => {
    const overlayMonth = yearOverlay?.data[idx];
    return {
      month: MONTH_LABELS[m.month - 1],
      avgTemp: m.avgTemp !== null ? Number(m.avgTemp.toFixed(1)) : null,
      range: m.avgMin !== null && m.avgMax !== null ? [m.avgMin, m.avgMax] : null,
      yearTemp:
        overlayMonth?.avgTemp !== null && overlayMonth?.avgTemp !== undefined
          ? Number(overlayMonth.avgTemp.toFixed(1))
          : null,
    };
  });

  return (
    <ResponsiveContainer width="100%" height={260}>
      <ComposedChart data={data} margin={{ top: 8, right: 16, left: -4, bottom: 0 }}>
        <CartesianGrid stroke={colors.grid} vertical={false} />
        <XAxis
          dataKey="month"
          stroke={colors.axis}
          tick={{ fill: colors.text, fontSize: 12 }}
          tickLine={false}
          axisLine={{ stroke: colors.grid }}
        />
        <YAxis
          stroke={colors.axis}
          tick={{ fill: colors.text, fontSize: 12 }}
          tickLine={false}
          axisLine={false}
          tickFormatter={(value) => `${value}°C`}
          width={52}
        />
        <Tooltip
          content={
            <ChartTooltip
              formatter={(value, name) =>
                name === "yearTemp"
                  ? `${(value ?? 0).toFixed(1)}°C (${yearOverlay?.year ?? ""})`
                  : name === "avgTemp"
                    ? `${(value ?? 0).toFixed(1)}°C prosječno`
                    : `${(value ?? 0).toFixed(1)}°C`
              }
            />
          }
        />
        {yearOverlay && (
          <Legend
            wrapperStyle={{ fontSize: 12, color: colors.text }}
            formatter={(value) =>
              value === "avgTemp" ? "Klimatski normal" : `${yearOverlay.year}.`
            }
          />
        )}
        <Area
          type="monotone"
          dataKey="range"
          name="Raspon min-max"
          stroke="none"
          fill={colors.brandLight}
          fillOpacity={0.18}
        />
        <Line
          type="monotone"
          dataKey="avgTemp"
          name="avgTemp"
          stroke={colors.brand}
          strokeWidth={2}
          dot={{ r: 3, fill: colors.brand }}
        />
        {yearOverlay && (
          <Line
            type="monotone"
            dataKey="yearTemp"
            name="yearTemp"
            stroke={colors.heat}
            strokeWidth={2}
            strokeDasharray="4 3"
            dot={{ r: 3, fill: colors.heat }}
            connectNulls
          />
        )}
      </ComposedChart>
    </ResponsiveContainer>
  );
}
