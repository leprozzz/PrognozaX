import type { ReactNode } from "react";

export interface DataTableColumn<T> {
  key: string;
  header: string;
  align?: "left" | "right";
  render: (row: T) => ReactNode;
}

interface Props<T> {
  columns: DataTableColumn<T>[];
  rows: T[];
  rowKey: (row: T) => string | number;
  highlightKey?: string | number;
}

export function DataTable<T>({ columns, rows, rowKey, highlightKey }: Props<T>) {
  return (
    <div className="max-h-96 overflow-auto rounded-md border border-zinc-200 dark:border-zinc-800">
      <table className="w-full min-w-[420px] border-collapse text-sm">
        <thead className="sticky top-0 bg-stone-50 dark:bg-[#14171a]">
          <tr>
            {columns.map((col) => (
              <th
                key={col.key}
                className={`border-b border-zinc-200 px-3 py-2 text-xs font-medium text-zinc-500 dark:border-zinc-800 dark:text-zinc-400 ${
                  col.align === "right" ? "text-right" : "text-left"
                }`}
              >
                {col.header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => {
            const key = rowKey(row);
            const isHighlighted = highlightKey !== undefined && key === highlightKey;
            return (
              <tr
                key={key}
                className={`border-b border-zinc-100 last:border-0 dark:border-zinc-800/60 ${
                  isHighlighted ? "bg-brand-50 dark:bg-brand-500/10" : ""
                }`}
              >
                {columns.map((col) => (
                  <td
                    key={col.key}
                    className={`data-figure px-3 py-2 text-zinc-700 dark:text-zinc-300 ${
                      col.align === "right" ? "text-right" : "text-left"
                    }`}
                  >
                    {col.render(row)}
                  </td>
                ))}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
