import { CalendarDays } from "lucide-react";

interface Props {
  value: string;
  onChange: (date: string) => void;
  min?: string;
  max?: string;
  todayValue: string;
}

export function DatePicker({ value, onChange, min, max, todayValue }: Props) {
  const isToday = value === todayValue;

  return (
    <div className="flex items-center gap-2">
      <div className="relative">
        <CalendarDays
          size={15}
          strokeWidth={2}
          className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-zinc-400"
        />
        <input
          type="date"
          value={value}
          min={min}
          max={max}
          onChange={(e) => onChange(e.target.value)}
          className="rounded-md border border-zinc-200 bg-white py-1.5 pl-8 pr-2.5 text-sm text-zinc-700 outline-none transition-colors hover:border-zinc-300 focus-visible:border-brand-500 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-200 dark:hover:border-zinc-600"
        />
      </div>
      {!isToday && (
        <button
          onClick={() => onChange(todayValue)}
          className="rounded-md border border-zinc-200 px-2.5 py-1.5 text-sm text-zinc-600 transition-colors hover:bg-zinc-100 dark:border-zinc-700 dark:text-zinc-300 dark:hover:bg-zinc-800"
        >
          Danas
        </button>
      )}
    </div>
  );
}
