import type { ReactNode } from "react";
import { Card } from "@/components/ui/Card";

export function ChartCard({
  title,
  subtitle,
  children,
}: {
  title: string;
  subtitle?: string;
  children: ReactNode;
}) {
  return (
    <Card>
      <div className="mb-3">
        <h3 className="font-display text-sm font-semibold text-zinc-900 dark:text-zinc-50">
          {title}
        </h3>
        {subtitle && (
          <p className="mt-0.5 text-xs text-zinc-500 dark:text-zinc-400">{subtitle}</p>
        )}
      </div>
      {children}
    </Card>
  );
}
