import { categorizeDelta, type ComparisonTone } from "@/utils/comparisonCategory";

interface Props {
  deltaFromAverage: number;
  /** Opis osnove poređenja, npr. "maksimalnih temperatura (07–23h)" */
  basisLabel: string;
}

const TONE_TEXT_COLOR: Record<ComparisonTone, string> = {
  "extreme-hot": "text-heat-600 dark:text-heat-400",
  hot: "text-heat-500 dark:text-heat-400",
  normal: "text-zinc-900 dark:text-zinc-50",
  cold: "text-cold-500 dark:text-cold-400",
  "extreme-cold": "text-cold-600 dark:text-cold-400",
};

/**
 * Vizuelno istaknuta rečenica koja kategoriše koliko je posmatrani dan
 * neobičan u odnosu na istoriju, po dogovorenim pragovima: >4°C
 * "toplije/hladnije nego obično", >8°C "ekstremno". Radi i za "danas"
 * (poredi live temperaturu sa prosjekom maksimalnih ili minimalnih
 * temperatura, zavisno od doba dana) i za bilo koji datum iz prošlosti
 * (poredi taj dan sa istorijskim prosjekom).
 */
export function ComparisonHeadline({ deltaFromAverage, basisLabel }: Props) {
  const category = categorizeDelta(deltaFromAverage);
  const deltaSign = deltaFromAverage >= 0 ? "+" : "";

  return (
    <div>
      <p className={`font-display text-xl font-semibold ${TONE_TEXT_COLOR[category.tone]}`}>
        {category.label}
      </p>
      <p className="data-figure mt-1 text-sm font-medium text-zinc-500 dark:text-zinc-400">
        {deltaSign}
        {deltaFromAverage.toFixed(1)}°C u odnosu na prosjek {basisLabel} za ovaj dan
      </p>
    </div>
  );
}
