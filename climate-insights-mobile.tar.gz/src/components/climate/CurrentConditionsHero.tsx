import { ArrowUp, ArrowDown, Droplets } from "lucide-react";

interface Props {
  label: string;
  value: number | null;
  todayMax: number | null;
  todayMin: number | null;
  precipitation: number | null;
  isLive: boolean;
}

export function CurrentConditionsHero({
  label,
  value,
  todayMax,
  todayMin,
  precipitation,
  isLive,
}: Props) {
  return (
    <div className="rounded-lg border border-zinc-200 bg-white p-5 dark:border-zinc-800 dark:bg-[#14171a]">
      <div className="mb-2 flex items-center gap-1.5">
        {isLive && (
          <span className="relative flex h-2 w-2">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-brand-500 opacity-75" />
            <span className="relative inline-flex h-2 w-2 rounded-full bg-brand-500" />
          </span>
        )}
        <span className="text-xs font-medium uppercase tracking-wide text-zinc-500 dark:text-zinc-400">
          {label}
        </span>
      </div>

      <div className="flex flex-wrap items-end gap-x-5 gap-y-2">
        <div className="data-figure font-display text-4xl font-semibold leading-none text-zinc-900 dark:text-zinc-50 sm:text-5xl">
          {value !== null ? `${value.toFixed(1)}°` : "—"}
        </div>

        <div className="flex flex-col gap-1 pb-0.5 text-sm">
          <span className="data-figure flex items-center gap-1 font-medium text-heat-600 dark:text-heat-400">
            <ArrowUp size={14} strokeWidth={2.5} />
            {todayMax !== null ? `${todayMax.toFixed(1)}°C` : "—"}
          </span>
          <span className="data-figure flex items-center gap-1 font-medium text-cold-600 dark:text-cold-400">
            <ArrowDown size={14} strokeWidth={2.5} />
            {todayMin !== null ? `${todayMin.toFixed(1)}°C` : "—"}
          </span>
        </div>

        {precipitation !== null && (
          <span className="data-figure mb-1 flex items-center gap-1.5 text-sm text-zinc-500 dark:text-zinc-400">
            <Droplets size={14} strokeWidth={2} />
            {precipitation.toFixed(1)} mm
          </span>
        )}
      </div>
    </div>
  );
}
