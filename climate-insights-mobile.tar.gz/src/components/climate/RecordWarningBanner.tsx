import { AlertTriangle } from "lucide-react";

interface Props {
  isNewRecord: boolean;
}

export function RecordWarningBanner({ isNewRecord }: Props) {
  return (
    <div className="flex items-center gap-2 rounded-md border border-heat-500/30 bg-heat-50 px-3 py-2 text-sm text-heat-700 dark:border-heat-500/30 dark:bg-heat-500/10 dark:text-heat-300">
      <AlertTriangle size={16} strokeWidth={2} className="shrink-0" />
      <span>
        {isNewRecord
          ? "Ovo je novi istorijski rekord za ovaj kalendarski dan!"
          : "Vrijednost je vrlo blizu istorijskog rekorda za ovaj kalendarski dan."}
      </span>
    </div>
  );
}
