import { NavLink } from "react-router-dom";
import { CalendarDays, BarChart3, Settings, Info } from "lucide-react";
import type { ComponentType } from "react";

interface NavItem {
  to: string;
  label: string;
  icon: ComponentType<{ size?: number; strokeWidth?: number }>;
  end?: boolean;
}

const navItems: NavItem[] = [
  { to: "/", label: "Danas", icon: CalendarDays, end: true },
  { to: "/statistics", label: "Statistika", icon: BarChart3 },
  { to: "/settings", label: "Settings", icon: Settings },
  { to: "/about", label: "About", icon: Info },
];

/**
 * Donja tab-bar navigacija za mobilne uređaje — Sidebar je skriven
 * ispod md breakpointa (vidi RootLayout), pa je ovo jedina navigacija
 * na telefonu. Fiksirana na dnu ekrana, sa safe-area paddingom za
 * iPhone home indicator.
 */
export function BottomNav() {
  return (
    <nav
      className="fixed inset-x-0 bottom-0 z-20 flex border-t border-zinc-200 bg-white/95 backdrop-blur dark:border-zinc-800 dark:bg-[#0e1114]/95 md:hidden"
      style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
    >
      {navItems.map(({ to, label, icon: Icon, end }) => (
        <NavLink
          key={to}
          to={to}
          end={end}
          className={({ isActive }) =>
            [
              "flex flex-1 flex-col items-center gap-0.5 py-2.5 text-[11px] transition-colors",
              isActive
                ? "text-brand-600 dark:text-brand-400"
                : "text-zinc-500 dark:text-zinc-400",
            ].join(" ")
          }
        >
          <Icon size={20} strokeWidth={2} />
          {label}
        </NavLink>
      ))}
    </nav>
  );
}
