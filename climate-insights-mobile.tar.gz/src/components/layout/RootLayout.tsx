import { Outlet } from "react-router-dom";
import { Sidebar } from "./Sidebar";
import { BottomNav } from "./BottomNav";
import { CitySwitcher } from "./CitySwitcher";
import { ThemeToggle } from "./ThemeToggle";
import { useThemeSync } from "@/hooks/useThemeSync";

export function RootLayout() {
  useThemeSync();

  return (
    <div className="flex min-h-screen bg-stone-50 dark:bg-[#0b0e11]">
      <Sidebar />

      <div className="flex min-h-screen flex-1 flex-col">
        <header className="flex h-14 shrink-0 items-center justify-between border-b border-zinc-200 bg-white/80 px-4 backdrop-blur dark:border-zinc-800 dark:bg-[#0e1114]/80 md:px-6">
          <div className="hidden text-sm text-zinc-500 dark:text-zinc-400 sm:block">
            Klimatska analiza gradova
          </div>
          <div className="flex items-center gap-2">
            <CitySwitcher />
            <ThemeToggle />
          </div>
        </header>

        {/* pb-20 na mobilnom ostavlja prostor da BottomNav ne prekriva sadržaj */}
        <main className="flex-1 px-4 py-6 pb-20 md:px-6 md:py-8 md:pb-8">
          <Outlet />
        </main>
      </div>

      <BottomNav />
    </div>
  );
}
