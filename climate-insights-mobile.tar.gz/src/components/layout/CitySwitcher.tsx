import { useCities } from "@/hooks/useCities";
import { useAppStore } from "@/store/useAppStore";

export function CitySwitcher() {
  const { data: cities, isLoading } = useCities();
  const selectedCityId = useAppStore((s) => s.selectedCityId);
  const setSelectedCityId = useAppStore((s) => s.setSelectedCityId);

  if (isLoading || !cities) {
    return <div className="h-8 w-36 animate-pulse rounded-md bg-zinc-100 dark:bg-zinc-800" />;
  }

  return (
    <select
      value={selectedCityId}
      onChange={(e) => setSelectedCityId(e.target.value)}
      className="rounded-md border border-zinc-200 bg-white px-2.5 py-1.5 text-sm font-medium text-zinc-700 outline-none transition-colors hover:border-zinc-300 focus-visible:border-brand-500 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-200 dark:hover:border-zinc-600"
    >
      {cities.map((city) => (
        <option key={city.id} value={city.id}>
          {city.name}
        </option>
      ))}
    </select>
  );
}
