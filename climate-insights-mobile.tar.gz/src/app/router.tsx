import { createBrowserRouter } from "react-router-dom";
import { RootLayout } from "@/components/layout/RootLayout";
import { OnThisDayPage } from "@/pages/OnThisDay/OnThisDayPage";
import { StatisticsPage } from "@/pages/Statistics/StatisticsPage";
import { SettingsPage } from "@/pages/Settings/SettingsPage";
import { AboutPage } from "@/pages/About/AboutPage";

export const router = createBrowserRouter([
  {
    path: "/",
    element: <RootLayout />,
    children: [
      { index: true, element: <OnThisDayPage /> },
      { path: "statistics", element: <StatisticsPage /> },
      { path: "settings", element: <SettingsPage /> },
      { path: "about", element: <AboutPage /> },
    ],
  },
]);
