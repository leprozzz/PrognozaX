import { useQuery } from "@tanstack/react-query";
import { getCities } from "@/data/cities";

export function useCities() {
  return useQuery({
    queryKey: ["cities"],
    queryFn: getCities,
    staleTime: Infinity,
  });
}
