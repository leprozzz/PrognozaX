import { useQuery } from "@tanstack/react-query";
import { historicalProvider } from "@/data/providers/HistoricalProvider";

export function useHistoricalData(cityId: string | undefined) {
  return useQuery({
    queryKey: ["historical", cityId],
    queryFn: () => historicalProvider.getHistoricalData(cityId!),
    enabled: Boolean(cityId),
    staleTime: 1000 * 60 * 60,
  });
}
