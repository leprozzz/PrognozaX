import { useAppStore } from "@/store/useAppStore";

export function useChartColors() {
  const theme = useAppStore((s) => s.theme);
  const isDark = theme === "dark";

  return {
    brand: "#0d9488",
    brandLight: "#5eead4",
    heat: "#e8590c",
    heatLight: "#f0762f",
    cold: "#2563eb",
    coldLight: "#4f7fef",
    grid: isDark ? "#27292c" : "#e4e4e7",
    axis: isDark ? "#71717a" : "#a1a1aa",
    text: isDark ? "#d4d4d8" : "#3f3f46",
    tooltipBg: isDark ? "#1c1f22" : "#ffffff",
    tooltipBorder: isDark ? "#2f3236" : "#e4e4e7",
    mutedFill: isDark ? "#3f3f46" : "#d4d4d8",
  };
}
