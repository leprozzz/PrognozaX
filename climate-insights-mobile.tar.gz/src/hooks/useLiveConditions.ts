import { useQuery } from "@tanstack/react-query";
import { liveProvider } from "@/data/providers/LiveProvider";

export function useLiveConditions(cityId: string | undefined) {
  return useQuery({
    queryKey: ["live", cityId],
    queryFn: () => liveProvider.getCurrentConditions(cityId!),
    enabled: Boolean(cityId),
    staleTime: 1000 * 60 * 10,
    refetchOnWindowFocus: false,
    retry: 1,
  });
}
