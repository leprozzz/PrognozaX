import { PageHeader } from "@/components/ui/PageHeader";
import { Card } from "@/components/ui/Card";

export function AboutPage() {
  return (
    <div className="max-w-2xl">
      <PageHeader title="About" />
      <Card>
        <p className="text-sm leading-relaxed text-zinc-600 dark:text-zinc-300">
          Climate Insights je aplikacija za istraživanje klimatskih podataka — ne samo prognoza,
          već kontekst: kako se današnji dan poredi sa istorijskim trendovima, koliko se klima
          promijenila kroz godine, i kako se gradovi međusobno razlikuju.
        </p>
        <p className="mt-3 text-sm leading-relaxed text-zinc-600 dark:text-zinc-300">
          Istorijski podaci dolaze sa{" "}
          <a
            href="https://meteostat.net"
            target="_blank"
            rel="noopener noreferrer"
            className="text-brand-600 underline-offset-2 hover:underline dark:text-brand-400"
          >
            Meteostat
          </a>{" "}
          i{" "}
          <a
            href="https://open-meteo.com"
            target="_blank"
            rel="noopener noreferrer"
            className="text-brand-600 underline-offset-2 hover:underline dark:text-brand-400"
          >
            Open-Meteo
          </a>{" "}
          (ERA5 reanalysis), trenutni uslovi sa Open-Meteo.
        </p>
      </Card>
    </div>
  );
}
