import { PageHeader } from "@/components/ui/PageHeader";
import { Card } from "@/components/ui/Card";
import { useAppStore } from "@/store/useAppStore";
import { useCities } from "@/hooks/useCities";

export function SettingsPage() {
  const theme = useAppStore((s) => s.theme);
  const setTheme = useAppStore((s) => s.setTheme);
  const { data: cities, isLoading: isLoadingCities } = useCities();

  return (
    <div className="max-w-xl">
      <PageHeader title="Settings" description="Podešavanja aplikacije." />

      <Card>
        <div className="mb-3 text-sm font-medium text-zinc-900 dark:text-zinc-50">Izgled</div>
        <div className="flex gap-2">
          {(["light", "dark"] as const).map((option) => (
            <button
              key={option}
              onClick={() => setTheme(option)}
              className={[
                "rounded-md border px-3 py-1.5 text-sm transition-colors",
                theme === option
                  ? "border-brand-500 bg-brand-50 text-brand-700 dark:bg-brand-500/15 dark:text-brand-300"
                  : "border-zinc-200 text-zinc-600 hover:bg-zinc-50 dark:border-zinc-700 dark:text-zinc-300 dark:hover:bg-zinc-800",
              ].join(" ")}
            >
              {option === "light" ? "Svijetla" : "Tamna"}
            </button>
          ))}
        </div>
      </Card>

      <Card className="mt-4">
        <div className="mb-1 text-sm font-medium text-zinc-900 dark:text-zinc-50">Gradovi</div>
        <p className="mb-3 text-xs text-zinc-500 dark:text-zinc-400">
          Grad se bira preko selektora u gornjem desnom uglu aplikacije. Ovdje je pregled svih
          dostupnih gradova.
        </p>

        {isLoadingCities && (
          <p className="text-sm text-zinc-500 dark:text-zinc-400">Učitavanje…</p>
        )}

        <div className="flex flex-col divide-y divide-zinc-100 dark:divide-zinc-800">
          {cities?.map((city) => (
            <div key={city.id} className="flex items-center justify-between py-2.5 text-sm">
              <div>
                <div className="font-medium text-zinc-800 dark:text-zinc-100">{city.name}</div>
                <div className="text-xs text-zinc-400 dark:text-zinc-500">{city.country}</div>
              </div>
              <div className="data-figure text-xs text-zinc-400 dark:text-zinc-500">
                {city.latitude.toFixed(2)}, {city.longitude.toFixed(2)}
              </div>
            </div>
          ))}
        </div>
      </Card>

      <Card className="mt-4 border-dashed">
        <p className="text-sm text-zinc-500 dark:text-zinc-400">
          Upravljanje izvorima podataka, jedinicama (°C/°F) i export podešavanjima dolazi u
          kasnijoj fazi.
        </p>
      </Card>
    </div>
  );
}
