import { useMemo, useState } from "react";
import { format } from "date-fns";
import { PageHeader } from "@/components/ui/PageHeader";
import { Card } from "@/components/ui/Card";
import { ChartCard } from "@/components/ui/ChartCard";
import { DataTable, type DataTableColumn } from "@/components/ui/DataTable";
import { DatePicker } from "@/components/ui/DatePicker";
import { ComparisonHeadline } from "@/components/climate/ComparisonHeadline";
import { RecordWarningBanner } from "@/components/climate/RecordWarningBanner";
import { CurrentConditionsHero } from "@/components/climate/CurrentConditionsHero";
import { useAppStore } from "@/store/useAppStore";
import { useCities } from "@/hooks/useCities";
import { useHistoricalData } from "@/hooks/useHistoricalData";
import { useLiveConditions } from "@/hooks/useLiveConditions";
import { getDailyComparison, getColdestDay } from "@/analytics";
import { nonNullValues } from "@/analytics/statsHelpers";
import { formatCalendarDayGenitive } from "@/utils/dateLabels";
import { getHourInTimezone, isDaytimeHour } from "@/utils/timezone";
import type { DailyRecord } from "@/types/weather";
import type { DailyComparison } from "@/types/analytics";

function todayIso(): string {
  return format(new Date(), "yyyy-MM-dd");
}

export function OnThisDayPage() {
  const selectedCityId = useAppStore((s) => s.selectedCityId);
  const [selectedDate, setSelectedDate] = useState(todayIso());

  const { data: cities } = useCities();
  const city = cities?.find((c) => c.id === selectedCityId);

  const { data: records, isLoading: isLoadingHistorical } = useHistoricalData(selectedCityId);

  const isToday = selectedDate === todayIso();

  const {
    data: live,
    isLoading: isLoadingLive,
    isError: isLiveError,
  } = useLiveConditions(isToday ? selectedCityId : undefined);

  const analysis = useMemo(() => {
    if (!records || records.length === 0) return null;

    const [yearStr, monthStr, dayStr] = selectedDate.split("-");
    const month = Number(monthStr);
    const day = Number(dayStr);
    const selectedYear = Number(yearStr);

    const suffix = `-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
    const historicalRecordsForDay: DailyRecord[] = records.filter(
      (r) => r.date.endsWith(suffix) && Number(r.date.slice(0, 4)) !== selectedYear,
    );

    let observedTavg: number | null = null;
    let observedTmax: number | null = null;
    let observedTmin: number | null = null;
    let observedPrcp: number | null = null;
    let hasObservedData = false;

    if (isToday) {
      if (live) {
        observedTavg = live.current;
        observedTmax = live.todayMax;
        observedTmin = live.todayMin;
        observedPrcp = live.precipitation;
        hasObservedData = true;
      }
    } else {
      const record = records.find((r) => r.date === selectedDate);
      if (record) {
        observedTavg = record.tavg;
        observedTmax = record.tmax;
        observedTmin = record.tmin;
        observedPrcp = record.prcp;
        hasObservedData = observedTavg !== null || observedTmax !== null;
      }
    }

    // Glavno poređenje ("headline"): za DANAS koristimo doba dana da
    // odaberemo ispravnu osnovu — 07-23h poredimo live temperaturu sa
    // istorijskim prosjekom MAKSIMALNIH temperatura za taj dan (jer je
    // dan još "u toku", pravi prosjek dana još ne postoji), a 23-07h sa
    // prosjekom MINIMALNIH. Za prošle datume dan je već završen, pa
    // koristimo pravi dnevni prosjek (tavg) naspram istorijskog tavg.
    let activeComparison: DailyComparison | null = null;
    let basisLabel = "";

    if (isToday && live) {
      const hour = getHourInTimezone(city?.timezone ?? "Europe/Sarajevo");
      const daytime = isDaytimeHour(hour);
      const metric = daytime ? "tmax" : "tmin";
      activeComparison = getDailyComparison(selectedDate, live.current, historicalRecordsForDay, metric);
      basisLabel = daytime
        ? "maksimalnih temperatura (07–23h)"
        : "minimalnih temperatura (23–07h)";
    } else if (observedTavg !== null) {
      activeComparison = getDailyComparison(selectedDate, observedTavg, historicalRecordsForDay, "tavg");
      basisLabel = "prosječne dnevne temperature";
    }

    // Za red statistika i upozorenje o rekordu uvijek posmatramo tmax
    // (bez obzira na doba dana) — "rekord" je uvijek o apsolutnom maksimumu.
    const maxComparison =
      observedTmax !== null
        ? getDailyComparison(selectedDate, observedTmax, historicalRecordsForDay, "tmax")
        : null;

    const coldestForDay = getColdestDay(historicalRecordsForDay);

    let maxPrecipitationEver: { value: number; year: number } | null = null;
    for (const r of historicalRecordsForDay) {
      if (r.prcp === null) continue;
      const year = Number(r.date.slice(0, 4));
      if (maxPrecipitationEver === null || r.prcp > maxPrecipitationEver.value) {
        maxPrecipitationEver = { value: r.prcp, year };
      }
    }

    const historicalAvgTemp =
      nonNullValues(historicalRecordsForDay.map((r) => r.tavg)).length > 0
        ? nonNullValues(historicalRecordsForDay.map((r) => r.tavg)).reduce((a, b) => a + b, 0) /
          nonNullValues(historicalRecordsForDay.map((r) => r.tavg)).length
        : null;

    return {
      month,
      day,
      hasObservedData,
      observedTavg,
      observedTmax,
      observedTmin,
      observedPrcp,
      activeComparison,
      basisLabel,
      maxComparison,
      coldestForDay,
      maxPrecipitationEver,
      historicalAvgTemp,
      historicalRecordsForDay,
    };
  }, [records, selectedDate, isToday, live, city]);

  const isLoading = isLoadingHistorical || (isToday && isLoadingLive);

  const yearColumns: DataTableColumn<DailyRecord>[] = [
    { key: "year", header: "Godina", render: (r) => r.date.slice(0, 4) },
    {
      key: "tmax",
      header: "Max",
      align: "right",
      render: (r) => (r.tmax !== null ? `${r.tmax.toFixed(1)}°C` : "—"),
    },
    {
      key: "tmin",
      header: "Min",
      align: "right",
      render: (r) => (r.tmin !== null ? `${r.tmin.toFixed(1)}°C` : "—"),
    },
    {
      key: "tavg",
      header: "Prosječna",
      align: "right",
      render: (r) => (r.tavg !== null ? `${r.tavg.toFixed(1)}°C` : "—"),
    },
    {
      key: "prcp",
      header: "Padavine",
      align: "right",
      render: (r) => (r.prcp !== null ? `${r.prcp.toFixed(1)} mm` : "—"),
    },
  ];

  return (
    <div>
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <PageHeader
          title="Na današnji dan"
          description="Poredi izabrani datum sa istorijskim podacima za isti kalendarski dan."
        />
        {records && records.length > 0 && (
          <DatePicker
            value={selectedDate}
            onChange={setSelectedDate}
            min={records[0].date}
            max={todayIso()}
            todayValue={todayIso()}
          />
        )}
      </div>

      {isLoading && (
        <Card>
          <p className="text-sm text-zinc-500 dark:text-zinc-400">Učitavanje podataka…</p>
        </Card>
      )}

      {!isLoading && isToday && isLiveError && (
        <Card className="mb-4 border-heat-500/40">
          <p className="text-sm text-heat-600 dark:text-heat-400">
            Nije moguće preuzeti trenutne vremenske uslove (provjeri internet konekciju).
            Poređenje sa istorijom trenutno nije dostupno za danas.
          </p>
        </Card>
      )}

      {!isLoading && analysis && !analysis.hasObservedData && (
        <Card>
          <p className="text-sm text-zinc-500 dark:text-zinc-400">
            Nema zabilježenih podataka za {formatCalendarDayGenitive(analysis.month, analysis.day)}{" "}
            {selectedDate.slice(0, 4)}. godine u dostupnom CSV-u.
          </p>
        </Card>
      )}

      {!isLoading && analysis && analysis.hasObservedData && (
        <div className="flex flex-col gap-4">
          {/* 1. Hero — trenutna/tog dana temperatura */}
          <CurrentConditionsHero
            label={isToday ? "Trenutna temperatura" : "Prosječna temperatura tog dana"}
            value={analysis.observedTavg}
            todayMax={analysis.observedTmax}
            todayMin={analysis.observedTmin}
            precipitation={analysis.observedPrcp}
            isLive={isToday}
          />

          {/* 2. Analiza dana */}
          {analysis.activeComparison && (
            <Card>
              <ComparisonHeadline
                deltaFromAverage={analysis.activeComparison.deltaFromAverage}
                basisLabel={analysis.basisLabel}
              />
              <p className="mt-2 text-xs text-zinc-400 dark:text-zinc-500">
                Zasnovano na {analysis.activeComparison.sampleSize}{" "}
                {analysis.activeComparison.sampleSize === 1 ? "godini" : "godina"} istorijskih
                podataka
              </p>
            </Card>
          )}

          {/* Upozorenje o rekordu */}
          {analysis.maxComparison?.isRecordCandidate && analysis.maxComparison.allTimeMax && (
            <RecordWarningBanner
              isNewRecord={
                analysis.observedTmax !== null &&
                analysis.observedTmax > analysis.maxComparison.allTimeMax.value
              }
            />
          )}

          {/* 3. Red: Najviša / Najniža / Najviše padavina / Prosječna (istorijski) */}
          <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
            <StatCard
              label="Najviša izmjerena"
              value={
                analysis.maxComparison?.allTimeMax
                  ? `${analysis.maxComparison.allTimeMax.value.toFixed(1)}°C`
                  : "—"
              }
              caption={
                analysis.maxComparison?.allTimeMax ? String(analysis.maxComparison.allTimeMax.year) : undefined
              }
              accent="heat"
            />
            <StatCard
              label="Najniža izmjerena"
              value={
                analysis.coldestForDay?.tmin !== null && analysis.coldestForDay?.tmin !== undefined
                  ? `${analysis.coldestForDay.tmin.toFixed(1)}°C`
                  : "—"
              }
              caption={analysis.coldestForDay ? analysis.coldestForDay.date.slice(0, 4) : undefined}
              accent="cold"
            />
            <StatCard
              label="Najviše padavina"
              value={
                analysis.maxPrecipitationEver ? `${analysis.maxPrecipitationEver.value.toFixed(1)} mm` : "—"
              }
              caption={analysis.maxPrecipitationEver ? String(analysis.maxPrecipitationEver.year) : undefined}
            />
            <StatCard
              label="Prosječna (istorijski)"
              value={analysis.historicalAvgTemp !== null ? `${analysis.historicalAvgTemp.toFixed(1)}°C` : "—"}
            />
          </div>

          {/* 4. Taj datum kroz godine */}
          {analysis.historicalRecordsForDay.length > 0 && (
            <ChartCard
              title={`${formatCalendarDayGenitive(analysis.month, analysis.day)} kroz godine`}
              subtitle="Pregled po godinama za isti kalendarski dan — najnovija godina prva"
            >
              <DataTable
                columns={yearColumns}
                rows={[...analysis.historicalRecordsForDay]
                  .sort((a, b) => b.date.localeCompare(a.date))
                  .slice(0, 15)}
                rowKey={(r) => r.date}
              />
            </ChartCard>
          )}
        </div>
      )}
    </div>
  );
}

function StatCard({
  label,
  value,
  caption,
  accent,
}: {
  label: string;
  value: string;
  caption?: string;
  accent?: "heat" | "cold";
}) {
  const valueColor =
    accent === "heat"
      ? "text-heat-600 dark:text-heat-400"
      : accent === "cold"
        ? "text-cold-600 dark:text-cold-400"
        : "text-zinc-900 dark:text-zinc-50";

  return (
    <Card>
      <div className="text-xs text-zinc-500 dark:text-zinc-400">{label}</div>
      <div className={`data-figure mt-1 text-xl font-semibold ${valueColor}`}>{value}</div>
      {caption && (
        <div className="data-figure mt-0.5 text-[11px] text-zinc-400 dark:text-zinc-500">
          {caption}
        </div>
      )}
    </Card>
  );
}
