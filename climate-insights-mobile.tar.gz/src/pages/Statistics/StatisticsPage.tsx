import { useMemo, useState } from "react";
import { PageHeader } from "@/components/ui/PageHeader";
import { Card } from "@/components/ui/Card";
import { ChartCard } from "@/components/ui/ChartCard";
import { YearSelector } from "@/components/ui/YearSelector";
import { DataTable, type DataTableColumn } from "@/components/ui/DataTable";
import { YearlyTemperatureTrendChart } from "@/components/charts/YearlyTemperatureTrendChart";
import { MonthlyAverageChart } from "@/components/charts/MonthlyAverageChart";
import { ExtremeDaysChart } from "@/components/charts/ExtremeDaysChart";
import { PrecipitationChart } from "@/components/charts/PrecipitationChart";
import { HeatwaveTimeline } from "@/components/charts/HeatwaveTimeline";
import { useAppStore } from "@/store/useAppStore";
import { useHistoricalData } from "@/hooks/useHistoricalData";
import { getYearSummary, getMonthlyAverage, getHeatwaves, getGrowingSeason } from "@/analytics";
import type { YearSummary } from "@/types/analytics";

const YEARS_WINDOW = 15;

export function StatisticsPage() {
  const selectedCityId = useAppStore((s) => s.selectedCityId);
  const { data: records, isLoading, isError, error } = useHistoricalData(selectedCityId);

  const allYears = useMemo(() => {
    if (!records) return [];
    return [...new Set(records.map((r) => Number(r.date.slice(0, 4))))].sort((a, b) => a - b);
  }, [records]);

  const [selectedYear, setSelectedYear] = useState<number | null>(null);
  const activeYear = selectedYear ?? allYears[allYears.length - 1] ?? null;

  const analysis = useMemo(() => {
    if (!records || records.length === 0 || activeYear === null) return null;

    const yearRows: YearSummary[] = allYears.map((year) => getYearSummary(records, year));
    const selectedRow = yearRows.find((r) => r.year === activeYear) ?? null;
    const growingSeason = getGrowingSeason(records, activeYear);

    const windowYears = allYears.slice(-YEARS_WINDOW);
    const windowSummaries = windowYears.map((year) => getYearSummary(records, year));

    const monthlyNormal = getMonthlyAverage(records); // klimatski normal, sve godine
    const monthlyForYear = getMonthlyAverage(records, activeYear);

    const allHeatwaves = getHeatwaves(records); // cijela istorija

    return {
      yearRows,
      selectedRow,
      growingSeason,
      windowYears,
      windowSummaries,
      monthlyNormal,
      monthlyForYear,
      allHeatwaves,
    };
  }, [records, allYears, activeYear]);

  const columns: DataTableColumn<YearSummary>[] = [
    { key: "year", header: "Godina", render: (r) => r.year },
    {
      key: "avgTemp",
      header: "Prosj. temp.",
      align: "right",
      render: (r) => (r.avgTemp !== null ? `${r.avgTemp.toFixed(1)}°C` : "—"),
    },
    { key: "summerDays", header: "Ljetni dani", align: "right", render: (r) => r.summerDays },
    { key: "frostDays", header: "Mrazni dani", align: "right", render: (r) => r.frostDays },
    {
      key: "precipitation",
      header: "Padavine",
      align: "right",
      render: (r) => `${r.totalPrecipitation.toFixed(0)} mm`,
    },
    { key: "daysWithData", header: "Dana sa podacima", align: "right", render: (r) => r.daysWithData },
  ];

  return (
    <div>
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <PageHeader
          title="Statistika"
          description="Detaljna analiza po godinama — trendovi, ekstremni dani, toplotni talasi i vegetacijska sezona."
        />
        {allYears.length > 0 && activeYear !== null && (
          <YearSelector years={allYears} value={activeYear} onChange={setSelectedYear} />
        )}
      </div>

      {isLoading && (
        <Card>
          <p className="text-sm text-zinc-500 dark:text-zinc-400">Učitavanje podataka…</p>
        </Card>
      )}

      {isError && (
        <Card className="border-heat-500/40">
          <p className="text-sm text-heat-600 dark:text-heat-400">
            Greška pri učitavanju: {(error as Error).message}
          </p>
        </Card>
      )}

      {analysis && analysis.selectedRow && (
        <div className="flex flex-col gap-4">
          {/* Stat kartice za izabranu godinu */}
          <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
            <StatCard
              label="Vegetacijska sezona"
              value={
                analysis.growingSeason.lengthDays !== null
                  ? `${analysis.growingSeason.lengthDays} dana`
                  : "—"
              }
              caption={
                analysis.growingSeason.startDate && analysis.growingSeason.endDate
                  ? `${analysis.growingSeason.startDate} → ${analysis.growingSeason.endDate}`
                  : "nema dovoljno podataka"
              }
            />
            <StatCard label="Ljetni dani (>30°C)" value={String(analysis.selectedRow.summerDays)} accent="heat" />
            <StatCard label="Mrazni dani (<0°C)" value={String(analysis.selectedRow.frostDays)} accent="cold" />
            <StatCard label="Tropske noći" value={String(analysis.selectedRow.tropicalNights)} accent="heat" />
          </div>

          {/* Godišnji trend temperature */}
          <ChartCard
            title="Godišnji trend temperature"
            subtitle={`Prosječna godišnja temperatura, posljednjih ${analysis.windowYears.length} godina`}
          >
            <YearlyTemperatureTrendChart summaries={analysis.windowSummaries} />
          </ChartCard>

          {/* Mjesečni prosjeci — klimatski normal + izabrana godina preko njega */}
          <ChartCard
            title="Mjesečni prosjeci"
            subtitle={`Klimatski normal (sve godine) sa istaknutom ${activeYear}. godinom`}
          >
            <MonthlyAverageChart
              monthlyAverages={analysis.monthlyNormal}
              yearOverlay={{ year: activeYear ?? 0, data: analysis.monthlyForYear }}
            />
          </ChartCard>

          {/* Ljetni i mrazni dani */}
          <ChartCard
            title="Ljetni i mrazni dani"
            subtitle={`Broj dana po godini, posljednjih ${analysis.windowYears.length} godina — ${activeYear}. istaknuta`}
          >
            <ExtremeDaysChart summaries={analysis.windowSummaries} selectedYear={activeYear ?? undefined} />
          </ChartCard>

          {/* Padavine */}
          <ChartCard
            title="Padavine"
            subtitle={`Ukupne godišnje padavine, posljednjih ${analysis.windowYears.length} godina — ${activeYear}. istaknuta`}
          >
            <PrecipitationChart summaries={analysis.windowSummaries} selectedYear={activeYear ?? undefined} />
          </ChartCard>

          {/* Toplotni talasi — cijela istorija */}
          <ChartCard
            title="Toplotni talasi — cijela istorija"
            subtitle={`Svi zabilježeni toplotni talasi (min. 3 uzastopna dana >30°C) od ${allYears[0]}. godine`}
          >
            <HeatwaveTimeline heatwaves={analysis.allHeatwaves} limit={15} />
          </ChartCard>

          {/* Tabela po godinama */}
          <ChartCard title="Pregled po godinama" subtitle="Izaberi godinu gore da promijeniš fokus">
            <DataTable
              columns={columns}
              rows={[...analysis.yearRows].reverse()}
              rowKey={(r) => r.year}
              highlightKey={activeYear ?? undefined}
            />
          </ChartCard>
        </div>
      )}
    </div>
  );
}

function StatCard({
  label,
  value,
  caption,
  accent,
}: {
  label: string;
  value: string;
  caption?: string;
  accent?: "heat" | "cold";
}) {
  const valueColor =
    accent === "heat"
      ? "text-heat-600 dark:text-heat-400"
      : accent === "cold"
        ? "text-cold-600 dark:text-cold-400"
        : "text-zinc-900 dark:text-zinc-50";

  return (
    <Card>
      <div className="text-xs text-zinc-500 dark:text-zinc-400">{label}</div>
      <div className={`data-figure mt-1 text-xl font-semibold ${valueColor}`}>{value}</div>
      {caption && (
        <div className="mt-0.5 text-[11px] text-zinc-400 dark:text-zinc-500">{caption}</div>
      )}
    </Card>
  );
}
