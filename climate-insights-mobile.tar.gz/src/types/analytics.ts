export interface YearSummary {
  year: number;
  avgTemp: number | null;
  maxTemp: number | null;
  minTemp: number | null;
  summerDays: number;
  hotDays: number;
  frostDays: number;
  tropicalNights: number;
  totalPrecipitation: number;
  daysWithData: number;
}

export interface MonthlyAverage {
  month: number;
  avgTemp: number | null;
  avgMin: number | null;
  avgMax: number | null;
  totalPrecipitation: number;
}

export interface Heatwave {
  startDate: string;
  endDate: string;
  durationDays: number;
  maxTemp: number;
}

export interface DailyComparison {
  date: string;
  currentValue: number;
  historicalAverage: number;
  deltaFromAverage: number;
  percentileRank: number;
  isRecordCandidate: boolean;
  allTimeMax: { value: number; year: number } | null;
  allTimeMin: { value: number; year: number } | null;
  sampleSize: number;
}

export interface HistoricalRanking {
  rank: number;
  totalRecords: number;
  percentile: number;
}

export interface RainAnomaly {
  period: string;
  actual: number;
  historicalAverage: number;
  deltaPercent: number;
}

export interface ClimateScore {
  year: number;
  score: number;
  label: string;
}

export interface GrowingSeason {
  year: number;
  startDate: string | null;
  endDate: string | null;
  lengthDays: number | null;
}
