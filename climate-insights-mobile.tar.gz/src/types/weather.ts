export interface DailyRecord {
  date: string;
  tavg: number | null;
  tmin: number | null;
  tmax: number | null;
  prcp: number | null;
}

export interface ForecastDay {
  date: string;
  tmin: number;
  tmax: number;
  precipitation: number;
}

export interface LiveSnapshot {
  cityId: string;
  current: number;
  todayMax: number;
  todayMin: number;
  precipitation: number;
  forecast: ForecastDay[];
  fetchedAt: string;
}
